public interface Demo
{
	public static void main(String[]args){
		System.out.println("Main() inside interface");
        }
}