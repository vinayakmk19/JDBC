public abstract class JDK14  extends javafx.application.Application
{
	static{
		System.out.println("Executing the programming without main()");
                System.exit(0);

	}
}