public class JDK7
{
	static{
		System.out.println("Executing the programming without main()");
                System.exit(0);

	}
}