public class JDK6
{
	static{
		System.out.println("Executing the programming without main()");
                System.exit(0);

	}
}