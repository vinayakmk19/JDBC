public enum Sample{
	a;
     public static void main(String[]args){
	System.out.println("Code without the user defined class");

    }

}