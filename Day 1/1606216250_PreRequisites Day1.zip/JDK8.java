public abstract class JDK8 extends javafx.application.Application
{
	static{
		System.out.println("Executing the programming without main()");
                System.exit(0);

	}
}