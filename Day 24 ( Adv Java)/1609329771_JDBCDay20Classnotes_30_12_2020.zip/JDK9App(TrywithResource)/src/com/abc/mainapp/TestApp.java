package com.abc.mainapp;

import java.util.Scanner;

public class TestApp {

	public static void main(String[] args) {

		try (Scanner scanner = new Scanner(System.in)) {

		}

	}

}
